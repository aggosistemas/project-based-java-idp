package com.example.simple_math_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleMathApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
